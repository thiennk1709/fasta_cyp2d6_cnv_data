
This directory contains fasta sequences used for generating simulated BAMs with CYP2D6 structural variants.

Truth calls can be found in the file `sv_truth_calls.txt`